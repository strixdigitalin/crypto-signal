export default function Page404() {
  return (
    <div style={{ margin: '200px 100px',textAlign:'center' }}>
      <h2>Page Not Found </h2>
    </div>
  );
}